from django.urls import path

from . import views

urlpatterns = [
    path('', views.Parser_list, name='Parser_list')
]
