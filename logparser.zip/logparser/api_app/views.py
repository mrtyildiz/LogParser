from django.shortcuts import render

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .parser import *

@api_view(['GET'])
def Parser_list(request):
    deneme = LogginParse()
    return Response(deneme)
